#import "ViewController.h"
#include "SearchModuleInfo.hpp"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    unsigned long* pulModBase = NULL;
    
    pulModBase = SearchModuleInfo::GetInstance()->GetModuleBase("SearchModule");
    
    const char *pszModPath = NULL;
    
    pszModPath = SearchModuleInfo::GetInstance()->GetModuleFullPath("SearchModule");
    
    printf("mod path:%s, mod base:%p", pszModPath, pulModBase);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
