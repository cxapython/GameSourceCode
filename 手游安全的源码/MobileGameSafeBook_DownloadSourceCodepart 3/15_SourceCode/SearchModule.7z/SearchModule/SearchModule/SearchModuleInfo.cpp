#include "SearchModuleInfo.hpp"

SearchModuleInfo* SearchModuleInfo::m_pInstance = NULL;

SearchModuleInfo::SearchModuleInfo()
{
    m_nModNum = 0;
    m_MapModuleList.clear();
    
    InitModInfo();
}

SearchModuleInfo::~SearchModuleInfo()
{
    map<char *, ModInfo*>::iterator itBegin = m_MapModuleList.begin();
    map<char *, ModInfo*>::iterator itEnd = m_MapModuleList.end();
    map<char *, ModInfo*>::iterator it = itBegin;
    for (; it != itEnd; it++)
    {
        if (it->first != NULL)
        {
            free(it->first);
        }
        
        if (it->second != NULL)
        {
            delete it->second;
        }
    }
    
    m_nModNum = 0;
    m_MapModuleList.clear();
}

SearchModuleInfo* SearchModuleInfo::GetInstance()
{
   
    if (m_pInstance == NULL)
    {
        printf("new SearchModuleInfo\n");
        m_pInstance = new  SearchModuleInfo();
    }
    
    return m_pInstance;
}

void SearchModuleInfo::InitModInfo()
{
    bool bJailBroken = true;
    
    if (bJailBroken)
    {
        FindRegion();
    }
    else
    {
        EnumDyldModules();
    }
}

void SearchModuleInfo::EnumDyldModules()
{
    m_nModNum = _dyld_image_count();
    
    for (int i = 0; i < m_nModNum; i++)
    {
        const mach_header* pstMachoHeader = _dyld_get_image_header(i);
        const char *pszImageFullPath = _dyld_get_image_name(i);
        
        ModInfo *pstModInfo = new ModInfo();
        pstModInfo->m_pszModPath = strdup(pszImageFullPath);
        pstModInfo->m_pulModBase = (unsigned long *)pstMachoHeader;
        m_MapModuleList[pstModInfo->m_pszModPath] = pstModInfo;
        
        printf("mod[%d]: %s-%p-%p\n", i, pszImageFullPath, pstMachoHeader, (unsigned long*)_dyld_get_image_vmaddr_slide(i));
    }
}

unsigned char * SearchModuleInfo::ReadProcessMemory(vm_map_t nTargetTask, mach_vm_address_t pbyReadAddr, mach_msg_type_number_t *pnReadSize)
{
    vm_offset_t pbyReadMemAddr;
    
    // Use vm_read, rather than mach_vm_read, since the latter is different
    // in iOS.
    kern_return_t kr = vm_read(nTargetTask,        // vm_map_t target_task,
                               pbyReadAddr,     // mach_vm_address_t address,
                               *pnReadSize,     // mach_vm_size_t size
                               &pbyReadMemAddr,     //vm_offset_t *data,
                               pnReadSize);     // mach_msg_type_number_t *nDyldAllImageInfoArrayCount
	if (kr) 
	{
		printf ("ReadProcessMemory: Unable to read target task's memory @%p - kr 0x%x\n" , pbyReadAddr, kr);
		return NULL;
	}
    
    return (unsigned char *)pbyReadMemAddr;
}

void SearchModuleInfo::ParseImageInfos(void *pbyDyldAllImageInfo)
{
    mach_msg_type_number_t  nDyldInfoCount = 0;
	mach_msg_type_number_t nDyldAllImageInfoArrayCount = 0;
    int nImageCount = 0;
    unsigned char *pbyDyldAllImageInfoContent = NULL;
    unsigned char *pbyDyldAllImageInfoArrayContent = NULL;
    
    do
    {
        nDyldInfoCount = sizeof(dyld_all_image_infos);

        pbyDyldAllImageInfoContent = ReadProcessMemory(mach_task_self(), (vm_address_t)pbyDyldAllImageInfo, &nDyldInfoCount);
        if (!pbyDyldAllImageInfoContent)
        {
            printf("ParseImageInfos: read mem failed 1\n");
            break;
        }
        
        struct dyld_all_image_infos * dyldaii = (struct dyld_all_image_infos *)pbyDyldAllImageInfoContent;
        
        printf("ParseImageInfos: Version: %d, %d images at offset %p\n",dyldaii->version, dyldaii->infoArrayCount, dyldaii->infoArray);
        
        nImageCount = dyldaii->infoArrayCount;
        nDyldAllImageInfoArrayCount = nImageCount * sizeof(struct dyld_image_info);
        
        pbyDyldAllImageInfoArrayContent = ReadProcessMemory(mach_task_self(), (mach_vm_address_t)dyldaii->infoArray, &nDyldAllImageInfoArrayCount);
        if (!pbyDyldAllImageInfoArrayContent)
        {
            printf("ParseImageInfos: read mem failed 1\n");
            break;
        }
        
        struct dyld_image_info *dii = (struct dyld_image_info *)pbyDyldAllImageInfoArrayContent;
        
        unsigned char *pszImageFilePath;
		mach_msg_type_number_t nPathNameLen;
        
        for (int i = 0; i < nImageCount; i++)
        {
            nPathNameLen = 1024;
            
            pszImageFilePath = ReadProcessMemory(mach_task_self(), (mach_vm_address_t)dii[i].imageFilePath, &nPathNameLen);
            
            ModInfo *pstModInfo = new ModInfo();
            
            if (pszImageFilePath)
            {
                pstModInfo->m_pszModPath = strdup((char *)pszImageFilePath);
                pstModInfo->m_pulModBase = (unsigned long *)dii[i].imageLoadAddress;
                m_MapModuleList[pstModInfo->m_pszModPath] = pstModInfo;
                
                vm_deallocate(mach_task_self(), (vm_offset_t)pszImageFilePath, 1024);
            }
            else
            {//解决获取不到主进程文件路径的问题
                struct dl_info curr_dl_info = {0};
                dladdr(dii[i].imageLoadAddress, &curr_dl_info);
                printf("ParseImageInfos: find process mod: %d:%p:%s\n", i, curr_dl_info.dli_fbase, curr_dl_info.dli_fname);
                
                pstModInfo->m_pszModPath = strdup(curr_dl_info.dli_fname);
                pstModInfo->m_pulModBase = (unsigned long *)dii[i].imageLoadAddress;
                m_MapModuleList[pstModInfo->m_pszModPath] = pstModInfo;
            }
            
            printf("ParseImageInfos: mod[%d] path:%s, mod base:%p\n", i, pstModInfo->m_pszModPath, pstModInfo->m_pulModBase);
        }
    } while (false);
    
    if (pbyDyldAllImageInfoContent != NULL)
    {
        vm_deallocate(mach_task_self(), (vm_offset_t)pbyDyldAllImageInfoContent, nDyldInfoCount);
    }
    
    if (pbyDyldAllImageInfoArrayContent != NULL)
    {
        vm_deallocate(mach_task_self(), (vm_offset_t)pbyDyldAllImageInfoArrayContent, nDyldAllImageInfoArrayCount);
    }
}

void * SearchModuleInfo::GetDyldAllImageInfosAddr(struct mach_header *pbyMachoHeader, const char *pszSymbolName)
{
	void *pbyDyldAllImageInfos = NULL;
	
    struct segment_command *pbyLindEditHdr = NULL;
    struct segment_command *pbyTextHdr = NULL;
    struct segment_command *pbyDataHdr = NULL;
    struct symtab_command *pbySymtabHdr = NULL;

	unsigned nLoadCmdCount = pbyMachoHeader->ncmds;
    struct load_command *pbyLoadCommand = (struct load_command *)((char *)pbyMachoHeader + sizeof(struct mach_header));
    
    for(unsigned i = 0; i < nLoadCmdCount; i++)
    {
		if(pbyLoadCommand->cmd == LC_SEGMENT)
		{
			struct segment_command *pbySegCommand = (struct segment_command *)pbyLoadCommand;

			if(strcmp(pbySegCommand->segname, "__LINKEDIT" ) == 0)
			{
				pbyLindEditHdr = pbySegCommand;
			}
			else if(strcmp(pbySegCommand->segname, "__TEXT") == 0)
			{
				pbyTextHdr = pbySegCommand;
			}
			else if(strcmp(pbySegCommand->segname, "__DATA") == 0)
			{
				pbyDataHdr = pbySegCommand;
			}
		}
		else if(pbyLoadCommand->cmd == LC_SYMTAB)
		{
			pbySymtabHdr = (struct symtab_command *)pbyLoadCommand;
		}
		
		if(pbyLindEditHdr && pbyTextHdr && pbySymtabHdr && pbyDataHdr)
		{
			break;
		}
        
        pbyLoadCommand = (struct load_command *)((char *)pbyLoadCommand + pbyLoadCommand->cmdsize);
    }
    
    if(!pbyLindEditHdr || !pbySymtabHdr || !pbySymtabHdr->symoff || !pbySymtabHdr->stroff || !pbyTextHdr || !pbyDataHdr)
    {
		printf("GetDyldAllImageInfosAddr: prepare failed\n");
        return pbyDyldAllImageInfos;
    }
    
    unsigned long ulImageSlide = (pbyTextHdr->vmsize - pbyTextHdr->filesize) + (pbyDataHdr->vmsize - pbyDataHdr->filesize);
	
    struct nlist *pbySymtabContent = (struct nlist *)( (unsigned long)pbyMachoHeader + pbySymtabHdr->symoff + ulImageSlide );
    const char *pbyStrtabContent = (const char *)( (unsigned long)pbyMachoHeader + pbySymtabHdr->stroff + ulImageSlide);
    
    unsigned nSymbolCount = pbySymtabHdr->nsyms;
    for(unsigned i = 0; i < nSymbolCount; i++)
    {
        struct nlist &SymItemRef = pbySymtabContent[i];
        if(SymItemRef.n_sect == NO_SECT)
        {
            continue;
        }
        
		char *pbySymItemName = (char *)(pbyStrtabContent + SymItemRef.n_un.n_strx);
        if(strcmp(pszSymbolName, pbySymItemName) == 0)
        {
            unsigned long ulDyldImageInfosOffset = SymItemRef.n_value - pbyTextHdr->vmaddr;
            pbyDyldAllImageInfos = (void *)( (unsigned long)pbyMachoHeader + ulDyldImageInfosOffset);
            break;
        }
    }
    
    return pbyDyldAllImageInfos;
}

bool SearchModuleInfo::FindListOfImage(task_t t, vm_address_t pbyMemHeader, vm_size_t size)
{
    void *pbyDyldAllImageInfos = 0;
    mach_msg_type_number_t nMagicSize = size;
    int nMachoSig = MH_MAGIC;
    
	if (pbyMemHeader == 0)
	{
		printf("FindListOfImage: arg null\n");
		return false;
	}
    
    unsigned char* pbyMachoHeader = ReadProcessMemory(t, (unsigned long)pbyMemHeader, &nMagicSize);
    if (pbyMachoHeader == NULL)
    {
        printf("FindListOfImage: read macho header failed\n");
        return false;
    }
    
    if (memcmp(pbyMachoHeader + 1, ((unsigned char *) &nMachoSig) + 1 , 3) != 0)
    {
        printf("FindListOfImage: is not macho\n");
        return false;
    }

	struct load_command* pbyLoadCommand = (load_command *)(((char *)pbyMachoHeader + sizeof(struct mach_header)));

	for (int k = 0; k < ((struct mach_header *)pbyMachoHeader)->ncmds; ++k)
	{
		if ((unsigned char*)pbyLoadCommand >= (unsigned char*)pbyMachoHeader + size)
		{
			printf("FindListOfImage: lc out of range\n");
			break;
		}
		
		printf("FindListOfImage: pbyLoadCommand index:%d, cmd:%d, size:%d\n", k, pbyLoadCommand->cmd, pbyLoadCommand->cmdsize);
		
		if (pbyLoadCommand->cmd == LC_ID_DYLINKER)
		{
			struct dylinker_command* pbyDyldCommand = (struct dylinker_command*)pbyLoadCommand;
			char *pszDyldName = (char *)pbyDyldCommand + pbyDyldCommand->name.offset;
			
			printf("FindListOfImage: %d, pbyDyldCommand name is:%s, name offset:%d, (pbyDyldCommand:%x, pbyDyldCommand name:%x)\n", k, pszDyldName, pbyDyldCommand->name.offset, pbyDyldCommand, pszDyldName);
			
			if (pszDyldName != NULL && strstr(pszDyldName, "/lib/dyld") != NULL)
			{
				// 从macho模块中找到"_dyld_all_image_infos"符号的地址
				pbyDyldAllImageInfos = GetDyldAllImageInfosAddr((struct mach_header *)pbyMemHeader, "_dyld_all_image_infos");
			}
			
			break;
		}
		
		// find next load command address
		pbyLoadCommand = (struct load_command *)((char*)pbyLoadCommand + pbyLoadCommand->cmdsize);
	}
    
    vm_deallocate(t, (vm_offset_t)pbyMachoHeader, nMagicSize);
    
    if (pbyDyldAllImageInfos)
    {
        ParseImageInfos(pbyDyldAllImageInfos);
        return true;
    }
    
    return false;
}

void SearchModuleInfo::FindRegion()
{
    kern_return_t kret;
    vm_address_t address = 1;
    int max = 1000;
    vm_address_t prev_address;
    
    vm_region_basic_info_data_t prev_info,info;
    vm_size_t size, prev_size;
    
    memory_object_name_t object_name;
    mach_msg_type_number_t count;
    
    int nsubregions = 0;
    int num_printed = 0;

    count = VM_REGION_BASIC_INFO_COUNT;
    kret = vm_region (mach_task_self(), &address, &size, VM_REGION_BASIC_INFO,
                      (vm_region_info_t) &info, &count, &object_name);
    
    if (kret != KERN_SUCCESS)
    {
        printf("FindRegion: mach_vm_region: Error %d - %s\n", kret, mach_error_string(kret));
        return;
    }
    
    memcpy (&prev_info, &info, sizeof (vm_region_basic_info_data_t));
    prev_address = address;
    prev_size = size;
    nsubregions = 1;
    
    for (;;)
    {
        int print = 0;
        int done = 0;
        
        address = prev_address + prev_size;
        
        /* Check to see if address space has wrapped around. */
        if (address == 0)
        {
            print = done = 1;
        }
        
        if (!done)
        {
            // Even on iOS, we use VM_REGION_BASIC_INFO_COUNT_64. This works.
            count = VM_REGION_BASIC_INFO_COUNT;
            kret = vm_region (mach_task_self(), &address, &size, VM_REGION_BASIC_INFO,
                              (vm_region_info_t) &info, &count, &object_name);

            if (kret != KERN_SUCCESS)
            {
                /* iOS 6 workaround - attempt to reget the task port to avoiD */
                /* "(ipc/send) invalid destination port" (1000003 or something) */
                kret = vm_region (mach_task_self(), &address, &size, VM_REGION_BASIC_INFO,
                                  (vm_region_info_t) &info, &count, &object_name);
            }
            
            if (kret != KERN_SUCCESS)
            {
                printf("FindRegion: mach_vm_region failed for address %p - Error: %x\n", (void *)address, (kret));
                size = 0;
                if (address >= USER_MAX_ADDRESS) return;
                print = done = 1;
            }
        }
        
        // 当前地址不是上一块内存的起始地址+内存长度，表示新的模块
        if (address != prev_address + prev_size)
        {
            print = 1;
        }
        
        // 当前内存块的权限和上一个内存块的权限不同
        if ((info.protection != prev_info.protection)
            || (info.max_protection != prev_info.max_protection)
            || (info.inheritance != prev_info.inheritance)
            || (info.shared != prev_info.shared)
            || (info.reserved != prev_info.reserved))
        {
            print = 1;
        }
        
        if (print)
        {
            int	print_size = 0;
            const char *print_size_unit = NULL;
            
            // 从此内存块中找出模块列表信息
            bool bRet = FindListOfImage(mach_task_self(), prev_address, prev_size);
            if (bRet == true)
            {
                done = 1;
            }
            
            /* Quick hack to show size of segment, which GDB does not */
            print_size = prev_size;
            if (print_size > 1024) { print_size /= 1024; print_size_unit = "K"; }
            if (print_size > 1024) { print_size /= 1024; print_size_unit = "M"; }
            if (print_size > 1024) { print_size /= 1024; print_size_unit = "G"; }
            /* End Quick hack */
            
            
            if (nsubregions > 1)
            {
                printf("FindRegion: (%d sub-regions)\n", nsubregions);
            }
            
            prev_address = address;
            prev_size = size;
            memcpy (&prev_info, &info, sizeof (vm_region_basic_info_data_t));
            nsubregions = 1;
            
            num_printed++;
        }
        else
        {
            prev_size += size;
            nsubregions++;
        }
        
        if (address >= USER_MAX_ADDRESS)
        {
            done = 1;
        }
        
        if (done)
        {
            break;
        }
    }
}

unsigned long* SearchModuleInfo::GetModuleBase(const char *pszModName)
{
    if (pszModName == NULL)
    {
        return NULL;
    }
    
    map<char *, ModInfo*>::iterator itBegin = m_MapModuleList.begin();
    map<char *, ModInfo*>::iterator itEnd = m_MapModuleList.end();
    map<char *, ModInfo*>::iterator it = itBegin;
    for (; it != itEnd; it++)
    {
        if (strstr(it->first, pszModName))
        {
            return (unsigned long*)(it->second->m_pulModBase);
        }
    }
    
    return NULL;
}

const char * SearchModuleInfo::GetModuleFullPath(const char *pszModName)
{
    if (pszModName == NULL)
    {
        return NULL;
    }
    
    map<char *, ModInfo*>::iterator itBegin = m_MapModuleList.begin();
    map<char *, ModInfo*>::iterator itEnd = m_MapModuleList.end();
    map<char *, ModInfo*>::iterator it = itBegin;
    for (; it != itEnd; it++)
    {
        if (strstr(it->first, pszModName))
        {
            return strdup(it->first);
        }
    }
    
    return NULL;
}

