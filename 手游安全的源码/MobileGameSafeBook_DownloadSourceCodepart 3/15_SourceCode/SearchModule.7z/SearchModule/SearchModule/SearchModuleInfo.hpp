#ifndef SearchModuleInfo_hpp
#define SearchModuleInfo_hpp

#include <stdio.h>
#include <stdlib.h>
#include <map>

#include <stdio.h>
#include <unistd.h>
#include <dlfcn.h>
#include <mach-o/loader.h>
#include <mach-o/dyld.h>
#include <mach/task.h>
#include <mach/task_info.h>
#include <mach-o/dyld_images.h>
#include <mach/vm_map.h>
#include <dlfcn.h>
#include <mach-o/nlist.h>

#ifdef __LP64__
#define USER_MAX_ADDRESS 0x80000000000
#else
#define USER_MAX_ADDRESS 0x40000000
#endif

using namespace std;

typedef struct modinfo
{
    char *m_pszModPath;
    unsigned long *m_pulModBase;
}ModInfo;

class SearchModuleInfo
{
public:
    static SearchModuleInfo* GetInstance();
    
    unsigned long* GetModuleBase(const char *pszModName);
    const char * GetModuleFullPath(const char *pszModName);
private:
    SearchModuleInfo();
    ~SearchModuleInfo();
    
    void InitModInfo();
    void EnumDyldModules();
    void FindRegion();
    bool FindListOfImage(task_t t, vm_address_t pbyMemHeader, vm_size_t size);
    
    void ParseImageInfos(void *pbyDyldAllImageInfo);
	void * GetDyldAllImageInfosAddr(struct mach_header *pbyMachoHeader, const char *pszSymbolName);
	unsigned char * ReadProcessMemory(vm_map_t target_task, mach_vm_address_t addr, mach_msg_type_number_t *size);
    
    static SearchModuleInfo *m_pInstance;
    int m_nModNum;
    map<char *, ModInfo*> m_MapModuleList;
};

#endif /* SearchModuleInfo_hpp */
