#include <stdio.h>
#include <stdlib.h>
#include <utils/PrintLog.h>

int Inject_entry()
{
	LOGD("Inject_entry Func is called\n");
	return 0;
}